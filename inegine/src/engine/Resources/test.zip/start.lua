SetTitle("�׽�Ʈ�Դϴ� ^^");
SetIcon("Resources/sampler/resources/test.ico");
SetSize(800, 600);
SetVolume(50);

dofile "Resources/Sampler/init.lua"